﻿package KopiLua;

public interface lua_Alloc {
	Object exec(ClassType t);
}