﻿package KopiLua;

public interface op_delegate {
	//lua_Number
	//lua_Number
	//lua_Number
	double exec(double a, double b);
}