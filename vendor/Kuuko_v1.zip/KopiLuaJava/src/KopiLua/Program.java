﻿package KopiLua;

public class Program {
	private static int main(String[] args) {
		if (false) {
			LuacProgram.MainLuac(args);
		}
		else {
			LuaProgram.MainLua(args);
		}
		return 0;
	}
}