﻿package KopiLua;

public class DateTimeProxy {
	public DateTimeProxy() {

	}

	public DateTimeProxy(int year, int month, int day, int hour, int min, int sec) {
		
	}

	public final void setUTCNow() {
		
	}

	public final void setNow() {
		
	}

	public final int getSecond() {
		return 0;
	}

	public final int getMinute() {
		return 0;
	}

	public final int getHour() {
		return 0;
	}

	public final int getDay() {
		return 0;
	}

	public final int getMonth() {
		return 0;
	}

	public final int getYear() {
		return 0;
	}

	public final int getDayOfWeek() {
		return 0;
	}

	public final int getDayOfYear() {
		return 0;
	}

	public final boolean IsDaylightSavingTime() {
		return true;
	}

	public final double getTicks() {
		return 0;
	}

	public static double getClock() {
		return 0;
	}
}