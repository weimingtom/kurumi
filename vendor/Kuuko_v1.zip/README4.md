﻿# Visual Novel Engine  

* http://homepage2.nifty.com/natupaji/DxLib/User/script_free.exe  
* https://hikaru02.github.io/open-novel/%E3%82%B9%E3%82%BF%E3%83%BC%E3%83%88.html  
* http://monogatari.hyuchia.com/demo/  
* https://github.com/navarro0/visual-novel-engine  
* http://www.singjchen.com/iPhoneVNE.html  
* https://github.com/Naouak/VNGuy  
* http://www.iihigate.eu/visual-novels/vn-reaching-out/  
* http://sis-tears.infernoayase.net/narcissu/  

* https://bless.moe/blog/po/97  
http://zaoyuhai.com/  

* http://lucid9.weebly.com/play.html  
https://forums.fuwanovel.net/index.php?/topic/4543-lucid9-project-a-mystery-vn/?  

* http://git.oschina.net/SunnyRx/ADV-PROGRAM  
https://github.com/weimingtom/adv_cocos2dx  

* https://github.com/search?q=TVPScriptEngine+ExecScript&type=Code&utf8=?  

* https://github.com/topwo/JuQing  
* https://github.com/rinkako/ProjectYuri  
* https://github.com/yinyanfr/NovelScript  
