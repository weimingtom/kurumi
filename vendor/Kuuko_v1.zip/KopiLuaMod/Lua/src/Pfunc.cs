﻿namespace KopiLua
{
	public interface Pfunc
	{
		void exec(lua_State L, object ud);
	} 
}
