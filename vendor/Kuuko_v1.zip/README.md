# Kuuko
Copy of kopilua, for someone in heaven.  
https://ja.wikipedia.org/wiki/%E6%9D%BE%E6%9D%A5%E6%9C%AA%E7%A5%90  
http://39miyu-chan.official.jp/  

Kuuko is the name of クー子 in Haiyore! Nyaruko-san.  
https://en.wikipedia.org/wiki/Nyaruko:_Crawling_with_Love  

**NOTE: this project is moved to https://github.com/weimingtom/kurumi**  
This project contains some notes for study which are not related to kopilua.  

## Ref  
* http://www.ppl-pilot.com/kopilua.aspx  

## History  
* 2017-03-03 : First running KopiLuaJava successfully (20:22 2017-03-03).  
* 2017-03-03 : Convert to Java successfully.  
* 2016-03-08 : First public modification.  
* 2015-10-27 : First private modification.  

## Converting Tool  
* C# to Java Converter 1.9  
http://www.tangiblesoftwaresolutions.com/  

## Script Engine List    
[README2.md](README2.md)  

## Database Engine List  
[README3.md](README3.md)  

## Visual Novel Engine  
[README4.md](README4.md)  
NOTE: moved to weimingtom/wmt_link_collections_in_Chinese  
https://github.com/weimingtom/wmt_link_collections_in_Chinese/blob/master/vn.md  

## Lua Hack     
[lua_hack.md](lua_hack.md)  
